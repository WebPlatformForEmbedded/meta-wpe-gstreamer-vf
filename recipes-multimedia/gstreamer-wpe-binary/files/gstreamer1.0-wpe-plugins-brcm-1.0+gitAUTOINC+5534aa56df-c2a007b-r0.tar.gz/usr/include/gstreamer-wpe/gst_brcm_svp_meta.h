/******************************************************************************
 *  Copyright (C) 2017 Broadcom. The term "Broadcom" refers to Broadcom Limited and/or its subsidiaries.
 *
 *  This program is the proprietary software of Broadcom and/or its licensors,
 *  and may only be used, duplicated, modified or distributed pursuant to the terms and
 *  conditions of a separate, written license agreement executed between you and Broadcom
 *  (an "Authorized License").  Except as set forth in an Authorized License, Broadcom grants
 *  no license (express or implied), right to use, or waiver of any kind with respect to the
 *  Software, and Broadcom expressly reserves all rights in and to the Software and all
 *  intellectual property rights therein.  IF YOU HAVE NO AUTHORIZED LICENSE, THEN YOU
 *  HAVE NO RIGHT TO USE THIS SOFTWARE IN ANY WAY, AND SHOULD IMMEDIATELY
 *  NOTIFY BROADCOM AND DISCONTINUE ALL USE OF THE SOFTWARE.
 *
 *  Except as expressly set forth in the Authorized License,
 *
 *  1.     This program, including its structure, sequence and organization, constitutes the valuable trade
 *  secrets of Broadcom, and you shall use all reasonable efforts to protect the confidentiality thereof,
 *  and to use this information only in connection with your use of Broadcom integrated circuit products.
 *
 *  2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED "AS IS"
 *  AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES, REPRESENTATIONS OR
 *  WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, WITH RESPECT TO
 *  THE SOFTWARE.  BROADCOM SPECIFICALLY DISCLAIMS ANY AND ALL IMPLIED WARRANTIES
 *  OF TITLE, MERCHANTABILITY, NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE,
 *  LACK OF VIRUSES, ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION
 *  OR CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING OUT OF
 *  USE OR PERFORMANCE OF THE SOFTWARE.
 *
 *  3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL BROADCOM OR ITS
 *  LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL, INCIDENTAL, SPECIAL, INDIRECT, OR
 *  EXEMPLARY DAMAGES WHATSOEVER ARISING OUT OF OR IN ANY WAY RELATING TO YOUR
 *  USE OF OR INABILITY TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF THE AMOUNT
 *  ACTUALLY PAID FOR THE SOFTWARE ITSELF OR U.S. $1, WHICHEVER IS GREATER. THESE
 *  LIMITATIONS SHALL APPLY NOTWITHSTANDING ANY FAILURE OF ESSENTIAL PURPOSE OF
 *  ANY LIMITED REMEDY.
 ******************************************************************************/


#ifndef __GST_BRCM_SVP_META_H__
#define __GST_BRCM_SVP_META_H__

#include <gst/gst.h>

G_BEGIN_DECLS

#define GST_BRCM_SVP_SYSTEM_ID_CAPS_FIELD "brcm-svp-meta"

#define GST_META_BRCM_SVP_TYPE_1   1 
#define GST_META_BRCM_SVP_TYPE_2   2
#define GST_META_BRCM_SVP_TYPE_3   3
typedef struct _chunk_info svp_chunk_info;
typedef struct _GstBrcmSvpMeta GstBrcmSvpMeta;
struct _chunk_info {
    guint32 clear_size;
    guint32 encrypted_size;
    guint32 offset; /* by type 3 */
};

typedef struct brcm_svp_meta_data {
    guint32 ref_cnt;
    guint32 sub_type;
    guint32 size;
    union {
        struct _u1 {
            guint32 secbuf_ptr;
        } u1;
        struct _u2 {
            guint32 secbuf_ptr;
            guint32 chunks_cnt;
            svp_chunk_info *chunk_info; 
        } u2;
        struct _u3 {
            guint32 secbuf_ptr;
            guint32 chunks_cnt;
            svp_chunk_info *chunk_info; 
        } u3;
    } u;
} brcm_svp_meta_data_t;

struct _GstBrcmSvpMeta
{
  GstMeta meta;
  brcm_svp_meta_data_t           * brcm_meta;
};

GType gst_brcm_svp_meta_api_get_type (void);

#define GST_BRCM_SVP_META_API_TYPE (gst_brcm_svp_meta_api_get_type())

#define gst_buffer_get_brcm_svp_meta(b) ((GstBrcmSvpMeta*)gst_buffer_get_meta ((b), GST_BRCM_SVP_META_API_TYPE))

#define GST_BRCM_SVP_META_INFO (gst_brcm_svp_meta_get_info())

const GstMetaInfo *gst_brcm_svp_meta_get_info (void);
typedef void (*brcm_svp_meta_release_cb_t)(void * ) ;
/* free function */

/*
 *  GstBuffer               *buffer  - buffer to which meta data will be added
 *  brcm_svp_meta_data_t    *brcm_meta    - metada 
 */
GstBrcmSvpMeta *gst_buffer_add_brcm_svp_meta (GstBuffer * buffer,  brcm_svp_meta_data_t * brcm_meta);
void gst_brcm_svp_meta_install_release_fn(guint32 sub_type, brcm_svp_meta_release_cb_t cb);

G_END_DECLS
#endif /* __GST_SVP_META_H__ */
